"""
Command line:

    python3 -m survivor check        # is everything wired up and logged correctly?
    python3 -m survivor recommend    # this week's Top-N recommendation

Both read the live Google Sheet described in config.toml. Neither ever
writes anything anywhere -- your pick only "counts" once YOU type it into
the Pools Picks tab, which is the whole point of the recommend/decide
separation in the design.

Options (both commands):
    --week N         Override the auto-detected current week.
    --config PATH    Use a config file other than ./config.toml.
    --csv-dir DIR    Read master_game_table.csv + pool_picks.csv from a
                     folder instead of Google Sheets (offline/testing).
recommend only:
    --top N          How many options per ranking (default from config).
    --save FILE      Also write the report to a Markdown file.
    --force          Produce a recommendation even if there are problems
                     that could make it wrong (not recommended).
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

from . import data_io, report
from .config import ConfigError, load_config


def _load_pool(args):
    """Returns (pool, top_n). Raises SystemExit with a readable message on failure."""
    if args.csv_dir:
        pool = data_io.load_pool_from_csv_dir(args.csv_dir, current_week=args.week)
        return pool, (getattr(args, "top", None) or 5)

    try:
        cfg = load_config(args.config)
    except ConfigError as e:
        sys.exit(f"Config problem: {e}")

    if not cfg.credentials.exists():
        sys.exit(
            f"Can't find your service account key at:\n  {cfg.credentials}\n"
            f"Edit the `credentials = ...` line in {cfg.path} to point at the "
            f"service_account.json you made for the grid engine.")

    try:
        data = data_io.read_google_sheet_tabs(
            cfg.spreadsheet, cfg.credentials,
            [cfg.master_game_table_tab, cfg.pools_picks_tab])
    except ImportError as e:
        sys.exit(str(e))
    except Exception as e:  # gspread raises several exception types; explain the common ones
        name = type(e).__name__
        if name == "SpreadsheetNotFound":
            sys.exit("Google says that spreadsheet doesn't exist or the service account "
                     "can't see it. Check the URL in config.toml, and that the sheet is "
                     "shared with the service account's email (the `client_email` in "
                     "service_account.json).")
        if name == "WorksheetNotFound":
            sys.exit(f"A tab wasn't found: {e}. Check the tab names in config.toml "
                     f"match the sheet exactly (capitalization and spaces count).")
        sys.exit(f"Couldn't read the Google Sheet ({name}): {e}")

    try:
        pool = data_io.build_pool_from_rows(
            data[cfg.master_game_table_tab], data[cfg.pools_picks_tab],
            current_week=args.week, my_player_label=cfg.my_player_label)
    except ValueError as e:
        sys.exit(str(e))
    return pool, (getattr(args, "top", None) or cfg.top_n)


def _summary(pool) -> str:
    r = pool.load_report
    lines = [f"Current week: {r.current_week} ({r.week_source})"]
    if r.my_picks:
        picks = ", ".join(f"W{wk} {team}" for wk, team in r.my_picks)
        lines.append(f"Your picks so far: {picks}")
    else:
        lines.append("Your picks so far: none logged")
    lines.append(f"Opponents still alive: {len(r.opponents_alive)}"
                 + (f" ({', '.join(r.opponents_alive)})" if r.opponents_alive else ""))
    if r.opponents_eliminated:
        lines.append(f"Opponents eliminated: {len(r.opponents_eliminated)} "
                     f"({', '.join(r.opponents_eliminated)})")
    return "\n".join(lines)


def _problems(pool) -> str:
    r = pool.load_report
    out = []
    if r.blocking:
        out.append("PROBLEMS (these could make a recommendation wrong):")
        out += [f"  - {m}" for m in r.blocking]
    if r.warnings:
        out.append("Notes (worth a look, won't break anything):")
        out += [f"  - {m}" for m in r.warnings]
    return "\n".join(out)


def cmd_check(args) -> int:
    pool, _ = _load_pool(args)
    print("Connected and loaded successfully.\n")
    print(_summary(pool))
    problems = _problems(pool)
    print()
    print(problems if problems else "No problems found. You're ready to run:  python3 -m survivor recommend")
    return 1 if pool.load_report.blocking else 0


def cmd_recommend(args) -> int:
    pool, top_n = _load_pool(args)
    r = pool.load_report
    print(_summary(pool))
    problems = _problems(pool)
    if problems:
        print()
        print(problems)
    if r.blocking and not args.force:
        print("\nNot producing a recommendation until the PROBLEMS above are fixed "
              "in the sheet (or re-run with --force if you understand the risk).")
        return 1

    rec = pool.get_recommendations(top_n=top_n)
    text = report.full_report(rec, len(pool.alive_opponents()))
    print("\n" + text)
    print(
        f"\nNext steps: make your week {r.current_week} pick on your pool's site, then "
        f"type it into Pools Picks (your row, 'Week {r.current_week}' column). After the "
        f"week, log everyone else's picks and mark anyone eliminated with OUT. "
        f"Nothing was recorded by running this.")
    if args.save:
        Path(args.save).write_text(text)
        print(f"(Report also saved to {args.save})")
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="python3 -m survivor",
                                     description="NFL Survivor DP optimizer")
    sub = parser.add_subparsers(dest="command", required=True)
    for name, helptext in (("check", "verify the sheet connection and your logged picks"),
                           ("recommend", "produce this week's recommendation")):
        p = sub.add_parser(name, help=helptext)
        p.add_argument("--week", type=int, default=None)
        p.add_argument("--config", default=None)
        p.add_argument("--csv-dir", default=None)
        if name == "recommend":
            p.add_argument("--top", type=int, default=None)
            p.add_argument("--save", default=None)
            p.add_argument("--force", action="store_true")
    args = parser.parse_args(argv)
    return {"check": cmd_check, "recommend": cmd_recommend}[args.command](args)
