# Testing the model on real NFL data

> **Status: executed.** Results, calibration changes and action items: **[BACKTEST_RESULTS.md](BACKTEST_RESULTS.md)**.
> The pilot section below (stand-in anchor) is kept for the record; it is superseded by the win-total backtest.

## Bottom line
1. **You do not need historical "full-season lines from Week 1".** That data does not exist in any public archive (books do not post
   it), and the model does not need it to be tested. Split the model into claims and test each with data that *does* exist.
2. The single best target is **line-to-line prediction**: "given information through week *k*, how well do I predict the *closing
   line* a game later gets?" Closing lines are near-noise-free measurements of market probability, so this needs a few hundred
   games to say something, versus roughly 6,000+ games (back-of-envelope) to detect the same improvement from win/loss outcomes.
3. Real data is reachable **now** for most of it (verified below). The one input I could not fetch is historical preseason win
   totals; the harness is ready for them. A first pilot on real closing lines already produced actionable results (§4).

## 1. What has to be true, and how each claim is tested

| # | Claim | Real data needed | Status |
|---|---|---|---|
| A | Win totals → schedule-adjusted ratings predict the market at the start of the season better than a naive prior | preseason win totals + weekly closing lines | harness ready; **needs win totals** |
| B | The Kalman filter tracks market strength week to week (calibrates `process_sd_per_week`, `fresh_line_sd`, `prior_sd`) | weekly closing lines | **done** (stand-in anchor) |
| C | The right amount of rating movement is passed into stale lines (calibrates sensitivity, gate, age curve, cap) | weekly closing lines (+ anchor) | **done** (stand-in anchor) |
| D | Data handling survives real data (team codes, neutral sites, byes, schedule changes) | nflverse schedule | partly (codes/neutral checked); full engine replay **not yet run** |
| E | End to end with *real game-specific stale lines* | this season's actual preseason lines + refreshes | **only testable prospectively (2026)** — §5 |

Why E cannot be done historically: a game's own stale line never existed in archives. The pilot therefore uses the rating-implied
line at the preseason as the stale anchor. The **comparison** adjusted-vs-stale stays valid (a game's idiosyncratic offset is common
to both and cancels); absolute error levels do not transfer.

## 2. Data sources

| Source | Provides | Access | Status |
|---|---|---|---|
| **nflverse `games.csv`** | every game 1999–2026: scores, week, **neutral-site flag**, rest, closing spread (all years), **closing moneylines (2006+, complete from 2010)**, spread/total prices | `https://raw.githubusercontent.com/nflverse/nfldata/master/data/games.csv` (also the `nflverse-data` GitHub release) | **Verified**: downloaded (2.2 MB) and profiled. Also contains your live 2026 season: 272 scheduled, 48 with lines, 17 played |
| **Pro-Football-Reference `preseason_odds` pages** | preseason **win totals** (and Super Bowl odds) per team-season | `https://www.pro-football-reference.com/years/YYYY/preseason_odds.htm` (I saw the 2003 page; a RotoWire study reports 2016–2025 assembled from PFR/SportsOddsHistory, filling gaps from ESPN and nfelo) | **Found, not fetched** (unreachable from my sandbox). One HTML table per season; `pandas.read_html`; rate-limit politely and check the site's terms |
| SportsOddsHistory.com | the archive PFR draws on | web | not checked |

Unverified from memory, check before relying on them: Australian sports-betting archives and Kaggle "spreadspoke" style files list
opening/closing lines (openers are only ~5 days stale, so useful just for short-horizon checks).

**Formatting for the harness:** one file per season, `win_totals_<season>.csv`, columns `Team, Win Total` (abbreviations or names).

## 3. The test ladder (cheapest first)

**L0 — audit (done for what I could check).** Map `OAK→LV, SD→LAC, STL→LAR, LA→LAR`; neutral games from `location == "Neutral"`
(3–8 per recent season); 2021 moved to 17 games/18 weeks (set `n_weeks`, `games_per_team` per era); 2020 had no fans (regression home
field 0.15 logit vs 0.21–0.25 in normal seasons; exclude 2020 from home-field averages); 2022 has 271 games.

**L1 — anchor accuracy (claim A).** For each season compute the anchor ratings from win totals (`--anchor win_totals`), then the RMSE of
`logit(closing p) − (r_h − r_a + hfa)` on Week 1 and Weeks 1–2. Compare with the carryover benchmark (below) and with a 50/50
blend. Pass: win totals clearly beat carryover. The Week-1 gap is also your **best real estimate of baseline mismatch**, which is
what sets `prior_sd` and `preseason_line_sd`.

**L2 — filter calibration (claim B).** Walk-forward one-step-ahead prediction of each week's closing lines; grid over the filter
parameters; choose on prior seasons, score on the next.

**L3 — pass-through calibration (claim C).** At each origin week, predict later closing lines three ways: stale anchor, filter output
in full, and the system's gated/age-weighted/capped policy. Regress realised change on estimated change to find the best slope,
by age and by movement size. Report season-clustered bootstrap intervals.

**L4 — full-engine replay (claim D).** Feed real seasons through the actual package (`init` with anchors, `refresh` with real closing
lines at your weekly cadence) to prove the code, not just the maths, on real data. *Not built yet.*

**L5 — prospective 2026 (claim E).** See §5.

**L6 — outcome sanity check (optional).** Log-loss vs game results for stale vs adjusted; only useful as a "not worse" check because of
the power problem in point 2 above.

**Rules that keep it honest:** no look-ahead (a game is predicted only from lines in earlier weeks; the anchor uses no results);
walk-forward by season, never tune and score on the same seasons; fix the primary metric in advance (RMSE of logit error against the
later closing line, games ≥ 2 weeks past the refreshed slate); cap tuned parameters at 3–4 (the calibration surface is flat, §4);
always report the stale and the full-pass-through benchmarks; use moneylines (same de-vig as production) from 2010 on. Closing lines
are a *stand-in* for the lines your API delivers mid-week; the real ones are earlier and noisier, so expect a somewhat larger
`fresh_line_sd`.

## 4. Pilot results — REAL closing lines, stand-in anchor (`backtest/pilot_real_data.py`, output in `backtest/pilot_output.txt`)

Setup: 2012–2025, ~4,200 real games with moneylines; anchor = prior-season market ratings regressed 25% toward the mean (a **stand-in**
because win totals were unavailable); origin = information through week *k*; targets = games ≥ 2 weeks later.

* **Benchmark for L1:** the carryover anchor predicts real **Week-1 closing lines with RMSE 0.452 logit** (≈ 3 points) and Weeks 1–2 with
  0.468. Win totals should beat this.
* **Filter dynamics (B):** one-step-ahead RMSE **0.419** logit in-sample, **0.432** walk-forward. The optimum is *flat*: weekly strength
  drift `process_sd_per_week` anywhere in ~0.09–0.18 and `fresh_line_sd` 0.14–0.23 are within 0.0004 RMSE of each other. Package defaults
  (0.08, 0.15) are at the conservative edge of that region — fine, but the data cannot tighten them.
* **Pass-through (C) — the important finding.** Passing the filter's estimated movement into later lines cut error by **19.8%**
  (90% CI 16.9–22.7%, over seasons). The package's current policy (age ramp, 0.12 dead-zone, 0.4 cap) captured only **10.0%**
  (9.1–10.8%). Best pass-through slope is **0.87–0.92 at every origin**, and even movements under 0.10 logit carry signal (slope 0.69;
  0.92–0.96 for 0.10–0.60).

  | Policy (same filter, same data) | Error cut vs stale | 90% CI |
  |---|---|---|
  | package defaults (start 3 wk, max 0.8, threshold 0.12, cap 0.4) | 10.0% | 9.1–10.8% |
  | no age dead-zone (start 0, half-weight 0.5 wk, max 0.9) | 13.0% | 11.7–14.3% |
  | + small gate (0.03) and cap 0.8 | 18.0% | 15.8–19.9% |
  | constant 0.9 pass-through, no gate, cap 1.5 | 19.9% | 17.2–22.4% |

**How to read this — and what it does not show.**
* The filter already shrinks by its own uncertainty (slope ≈ 0.9 says it is nearly calibrated), so stacking an age ramp, a threshold and a
  tight cap on top discards roughly half the available gain. That is a **policy** cost, not a modelling one.
* **The gain is inflated by the weak anchor.** A carryover prior is far worse than a real preseason line (stale RMSE 0.77 here); with a
  good anchor there is less to correct. The *slope* should transfer better than the *size of the gain*. Do not expect 20%.
* The pilot cannot test the "no adjustment to lines younger than 3 weeks" rule (every origin is ≥ 3.7 weeks) or separate line staleness
  from anchor quality; it only shows the *ramp* is costly. Freshness protection is a hierarchy choice you made, not something these data
  contradict.
* Four policies were hand-picked, not searched, so selection bias is small but not zero; they are not adopted as defaults.

**Candidate policy for a shadow test (not adopted):** `aging.start_age_weeks = 0`, `half_weight_weeks = 0.5`, `max_weight = 0.9`,
`strength.threshold_up = 0.03`, `adjust.cap = 0.8`.

## 5. Prospective test on the live 2026 season (the only fully clean test of E)
1. **Freeze the config now** (record its hash) and write down the primary metric before looking at results.
2. **Archive every raw API pull** with its timestamp (the engine keeps master versions, ratings and reports but not the raw tables;
   without them you cannot replay alternative policies later).
3. The engine already scores, every run, last run's adjusted probabilities against the fresh lines that just arrived
   (`state/runs/*.json → details.adjustment_skill`). Expect roughly 200 scored games over the season: enough to tell "clearly helping"
   from "clearly hurting", not to fine-tune.
4. At season end, replay the saved inputs under the candidate policy and compare, and use nflverse's 2026 closing lines as an independent
   truth for the same games.

## 6. Next steps
* **You:** pull preseason win totals for 2012–2025 (PFR pages above) into `win_totals_<season>.csv`; then
  `python backtest/pilot_real_data.py --anchor win_totals --win-totals-dir <dir>` gives L1–L3 with the real anchor (plumbing verified with
  clearly-fake files; real-file behaviour untested).
* **Me, if you want:** (a) the L4 full-engine replay on 2021–2025; (b) shadow-policy logging so two configs are scored side by side in
  live runs; (c) a raw-input archiver. Do not change production defaults until L1–L3 have been rerun with real win totals.
