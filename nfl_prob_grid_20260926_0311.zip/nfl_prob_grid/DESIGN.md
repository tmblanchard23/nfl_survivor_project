# NFL Season-Long Probability Grid — Design

Scope: **probability-grid maintenance only.** No Survivor selection, optimisation, future-value,
assignment or survival-probability logic exists anywhere in this project. Teams are entities attached
to game win probabilities.

> **Calibrated on real data (2012–2025).** Adjustment-policy defaults were retuned from a real-data backtest; see
> **[BACKTEST_RESULTS.md](BACKTEST_RESULTS.md)**. Where this document and that report disagree on a number, the report wins.

## 0. Review of the win-total-anchored strength approach (what changed and why)

**Verdict: sound in structure, and materially better than the Super Bowl proxy it replaces** — it
measures the same market as the lines being adjusted, at game level, with no playoff-path or
banked-record contamination. As literally stated ("baseline = win totals, adjust from there") it had
four flaws; each is fixed below. Two second-order caveats follow.

| # | Flaw in the literal approach | Consequence | Fix (implemented) |
|---|---|---|---|
| 1 | **Baseline mismatch.** The stale lines were set by the *game* market; win totals come from a different market. | Any team-level gap looks like "movement" once fresh lines arrive → a stale line is adjusted for something that never happened (the double-counting you wanted to avoid). | Win totals are the **prior**; the preseason game lines refine it with a tunable weight (`preseason_line_sd`). `init` prints the win-total-vs-lines gap and the weight. Pure win totals: `reconcile_preseason_lines = false`. |
| 2 | **A pull-back target.** Win totals cannot be refreshed. | If ratings drifted back toward them, real changes (injury, breakout) would be erased. | Used **once, at t = 0**, as a prior. Process noise inflates uncertainty every week, so the prior's influence fades as evidence accumulates. |
| 3 | **Wins ≠ ratings.** | Win% → logit ignores schedule strength and home/away; posted totals also sum to more than the games played (books shade them). | Newton solve for ratings that reproduce each team's expected wins over its **actual schedule** (home/away aware); vig removed (`normalize`); optional over/under price shades each total to a mean. |
| 4 | **One line cannot say which team moved.** A single game identifies only `r_home − r_away`; the errors of the two teams become *positively correlated* (you know the difference, not the sum). Sparse 1–2 week refreshes make attribution ambiguous. | Splitting a change 50/50 between the two teams is wrong for a team whose *other* games show the same shift. | A **Kalman filter** carrying the full 32×32 covariance across runs, so evidence accumulates game by game (tested: three games all favouring A attribute more to A than one game does), plus weekly process noise. |

Second-order caveats:
* **Win totals matter less than you might expect once the preseason lines are included.** Each team has
  17 preseason lines but one win total, so a correct blend leans on the lines. Win totals remain valuable
  as an independent, lower-noise, team-level anchor for the level of each rating (individual far-future
  lines are thin and noisy). On the synthetic data the default gives them ~50% of the baseline (table in §7)
  and all three baseline choices end at about the same accuracy, because the prior fades — but the
  pure-win-total baseline adjusts noticeably more games (72% vs 58%), the signature of baseline-mismatch
  "movement". The size of the gap on **your** data is what `init` reports.
* **The age curve is now a policy overlay, not an estimator.** Movement measured since the line's own
  timestamp is already the expected drift of that line, so a fully Bayesian model would adjust a 2-week-old
  line too. The "no adjustment until ~3 weeks old" rule and the ramp are your hierarchy (fresh lines highest
  confidence) and are kept as specified; they make the system more conservative than optimal.

Additions beyond the request: neutral-site handling, lookahead-line noise, a home-field estimator that is
not fooled by schedule imbalance, and a live **adjustment-skill check** (every run scores last run's
adjusted-vs-unadjusted probabilities against the lines that just arrived).

## 1. Architecture

A *stateful weekly refresh engine*. The single source of truth is the game-level **master table**; each
run reads the latest version, produces the next, and never rebuilds from the preseason table.

```
state/
  master_current.csv          latest master (what the next run loads)
  versions/master_v0001.csv   immutable copy of every version
  ratings_history.csv         append-only team-rating snapshots (snapshot 0 = baseline)
  rating_state.json           filter covariance, home-field advantage, baseline audit table
  changes/changes_v000N.csv   per-game diff vs previous version
  runs/run_v000N.json         run report: counts, diagnostics, warnings, every rejected input row
  manifest.json               version list + sha256 hash chain (master, ratings, rating state)
output/
  prob_grid_latest.csv        Team x Week 1..18 grid (bye = blank), derived from the master
  master_game_table_latest.csv
  team_ratings_latest.csv     the market-perceived power ratings (current, baseline, win-total, change)
  team_ratings_history.csv    ratings after every run
```

Run sequence (`engine.apply_refresh`; pure, all I/O is in `run_refresh`):

| Spec step | What happens |
|---|---|
| 1–2 | Load verified master; `current_week` may never decrease; **freeze** all weeks `< current_week` |
| 3–4 | Read incoming table (any size); standardise, normalise team names, parse timestamps, reject bad rows; match to master by id/key (never row order); collapse duplicates |
| 5–6 | Only if `incoming_ts > stored last_vegas_refresh_ts`: replace the anchor with the newly de-vigged probability, update the timestamp |
| 7 | Freezing is done *first* (step 2) so nothing after it can touch a completed week |
| 8 | **Kalman update** of team ratings from exactly the lines refreshed in this run; new snapshot; each refreshed game stores the snapshot that already contains its line |
| 9–11 | For every active game: line age → age weight → rating movement since that snapshot (both teams) → meaningful-movement gate → anchored log-odds adjustment |
| 12 | Validate. Any error aborts; **nothing is written** |
| 13 | Atomic commit: version file, rating files, reports, `master_current.csv`, manifest **last** |

### Two deliberate refinements of the literal spec (both driven by double counting, §17)

**A. Adjustments are anchored, not stacked.** The master stores `latest_vegas_home_prob` (the *anchor*: the
last real, de-vigged line). `home_win_prob = link⁻¹(link(anchor) + adj)`, where `adj` is recomputed each run
from the anchor, current movement and current age, and **replaces** last run's adjustment. Adjusting the
already-adjusted probability would re-apply the same rating change every week. This is not a preseason
rebuild: the anchor is the latest actual line. Adjustments also un-wind if a team's rating reverts.

**B. Movement is measured from the rating snapshot that already contained the line.** A line accepted in
run *k* is itself an observation that moved the ratings in snapshot *k*; movement since a *earlier*
snapshot would count that information twice. Each game therefore stores `anchor_rating_snapshot_id`
(0 for preseason lines, *k* for a line refreshed in run *k*) and movement is `rating(now) − rating(anchor
snapshot)`. Exact bookkeeping — no timestamp tolerance to tune. `strength.reference = "preseason"` gives the
literal behaviour; a test shows it double-counts and a mutation test confirms the suite catches its return.

## 2. Mathematical methodology

### 2.1 De-vigging
`q_i = 1/decimal_odds`; overround `S = Σq`. Default *proportional*: `p_i = q_i/S`, so home + away = 1.
Optional *power* method (`Σ q_i^k = 1`, bisection). Rows are rejected (not guessed) for missing/non-numeric
odds, odds below 1.01, odds above a cap, `S < 1` (arbitrage / data error) and `S > 1.25`.

### 2.2 Market-perceived strength (ratings)
Model, in logit units: `logit P(home wins) = r_home − r_away + hfa` (`hfa = 0` for neutral games).

1. **Home field.** `hfa` is the intercept of a regression of the preseason logits on team effects, *not*
   the mean home logit: that mean also contains the strength gap between the teams that happen to be at home
   and away. (On the demo schedule the naive mean reads 0.10; the true value and the regression give 0.25;
   a regression test locks this in.) `hfa_mode = "fixed"` overrides.
2. **Anchor (t = 0).** Win totals → expected wins (over/under price shades the total to a mean:
   `total + wins_sd · Φ⁻¹(P_over)`) → vig removed (`normalize`, additive by default so the targets sum to the
   number of games) → Newton solve `Σ_games P(team wins) = target` over the actual schedule (ratings mean 0).
   Prior: `r ~ N(r_win, prior_sd² I)`.
3. **Reconcile.** The 272 preseason lines are folded in as noisy observations `logit p − hfa = r_h − r_a + e`,
   `e ~ N(0, preseason_line_sd²)`. Larger noise ⇒ win totals dominate; `1e6` ≡ pure win totals. Diagnostics
   (independent of that setting): RMS gap between win-total-implied and lines-implied ratings, in logit and
   in wins; the weight the baseline puts on win totals; largest per-team gaps.
4. **Update (every refresh).** Random-walk time update `P ← P + process_sd² · Δt_weeks · I`, then a
   measurement update from each newly refreshed line, noise
   `fresh_line_sd² + (lookahead_sd_per_week · weeks_beyond_next_slate)²` (thin lookahead lines teach the filter
   less). Joseph-form covariance update; ratings re-centred; means unchanged by time passing alone.

### 2.3 Movement and the meaningful-movement gate
`movement_i = rating_i(now) − rating_i(anchor snapshot)`, centred on the league median (removes league-wide
drift). It is already in game log-odds units, so the default sensitivity is 1.0. Per-team gate with separate
up/down thresholds (`symmetric = true` ties them); default **0.02 logit** (backtested: real moves carry signal down
to ~0.05 logit, so the gate only suppresses churn). Default **soft**
gating: only the part beyond the threshold counts (continuous). **Hard** gating creates a cliff and worsens
Case C (a team just over the threshold beside one just under produces a large adjustment from a tiny relative
difference). `shift_i = sign(m_i) · sens · (|m_i| − θ)⁺`.

### 2.4 Line-age weighting
`w(age)` = trust in the movement signal; `w = 0` for `age ≤ start_age` (3 weeks). If strength drifts as a
random walk, the error variance of a stale line grows linearly with age while the signal has fixed noise; the
optimal blend weight (a Kalman gain) is `x/(x+h)`, a **saturating hyperbola**: `w = w_max · x/(x+h)`,
`x = age − 3`, `w_max = 1.0`, `h = 0.5` weeks (backtested: reproduces the measured pass-through slopes 0.81–0.92). Two intuitive parameters, steep-then-flat, never above `w_max`.
Alternatives are in the config; weights for the defaults:

| Age (weeks) | 3 | 4 | 5 | 6 | 7 | 10 | 14 | 17 |
|---|---|---|---|---|---|---|---|---|
| **hyperbolic (default)** | 0 | .667 | .800 | .857 | .889 | .933 | .957 | .966 |
| linear (12 wk ramp) | 0 | .083 | .167 | .250 | .333 | .583 | .917 | 1.00 |
| exponential | 0 | .221 | .393 | .528 | .632 | .826 | .936 | .970 |
| logistic (mid 7 wk) | 0 | .046 | .134 | .282 | .480 | .913 | .996 | 1.00 |
| step (4/5/6/7 wk) | 0 | .150 | .300 | .450 | .600 | .600 | .600 | .600 |

Linear ignores saturation; step has cliffs and cannot tell 7 from 17 weeks; logistic needs a midpoint with no
physical meaning here; exponential is a close second. "Baseline influence" in your table is `1 − w`.

### 2.5 Applying the adjustment (log-odds, both teams)
```
delta  = shift_home − shift_away                      # antisymmetric between the two teams
adj    = cap · tanh( w · delta / cap )                # smooth cap, default 1.0 logit (backtested)
p_home = σ( logit(anchor_home) + adj ),   p_away = 1 − p_home
```
Log-odds is the natural space of Elo / Bradley–Terry: a rating change enters as `Δr_home − Δr_away`, so cases
A–E fall out with no special-casing (A/B one team moves; C both improve → relative movement decides, equal
moves cancel; D opposite moves compound; E both decline). Bounded in (0,1), complementary by construction,
self-attenuating near the boundaries (the maximum 1.0 shift is +23pp at 50%, +12pp at 80%, +3pp at 95%).
*Multiplicative* adjustment can exceed 100% for favourites and is asymmetric between the teams;
renormalised it becomes a log-odds shift anyway. `probit` is available as an alternative link.

**Worked example** (backtested defaults): Team A at home, anchor 65.0%, line 7 weeks old (`w = .889`).
A's rating +0.30 vs the league, B unchanged: `shift_A = 0.30 − 0.02 = 0.28`, `adj = 0.244` ⇒ **65.0% → 70.3%**.
A +0.30 and B −0.30 ⇒ **74.6%**. A −0.30 ⇒ **59.3%**.

### 2.6 Hierarchy / no double counting
Fresh line → used as is (age ≈ 0 ⇒ `w = 0`; a test asserts it survives a huge rating shift). Older line → still
the anchor. Rating movement → only a bounded, age-weighted log-odds nudge to an old anchor, measured since the
snapshot that already contained that anchor (§1-B) and never stacked (§1-A).

## 3. Assumptions that are configurable (all in `config.toml`)
Paths / sheet URLs · column names (case-insensitive) · team aliases · `current_week` · timezone / timestamp
format / age unit · matching options · de-vig method and odds limits · **rating model**: hfa mode, win-total
normalisation and O/U shading, `prior_sd`, reconcile on/off and `preseason_line_sd`, `process_sd_per_week`,
`fresh_line_sd`, lookahead noise, neutral-site games · movement centring, reference mode, symmetric flag,
thresholds, sensitivities, soft/hard gating · age curve and every curve parameter · link, cap, cap shape ·
strictness, reject fraction, integrity check · grid labels and rounding.

## 4. Validation and failure behaviour
*Row-level* problems (unknown team, missing/invalid odds, bad week or timestamp, unmatched game, game in an
unexpected week, conflicting duplicates, future timestamps) → the row is rejected with a reason code and
reported; others proceed. If more than `max_reject_fraction` of rows fail the run **aborts**; `strict = true`
aborts on any rejection. *Master-level* invariants (every run; any failure aborts, nothing written): unique
games; canonical teams; one game per team per week; probabilities finite, in (0,1), complementary;
`latest_vegas_home_prob` reproducible from stored odds; `home_win_prob` reproducible from anchor + `adj_logit`;
source flags consistent; game set, schedule and original Vegas fields unchanged; **frozen games unchanged (exact
equality)**; completed weeks marked frozen. *Win-total table:* any missing/duplicate/unknown team, non-numeric
or implausible total, or bad over/under price refuses the whole table at `init` (a partial anchor would distort
the league-wide solve). Tampered or half-written state (master **or** rating state) is refused on load.

## 5. Data lineage (master table fields)
`prob_source` ∈ {`VEGAS_FRESH`, `VEGAS_OLDER`, `VEGAS_PRESEASON`, `VEGAS_STALE_ADJUSTED`}. Vegas:
`original_vegas_home_prob/_ts`, `latest_vegas_home_prob`, `latest_home_odds/_away_odds`, `last_vegas_refresh_ts`,
`refresh_count`, `last_refresh_version`. Ratings/adjustment: `anchor_rating_snapshot_id`, `adj_active`,
`adj_logit`, `adj_home_prob_delta`, `line_age_weeks`, `age_weight`, `home_rating_move`/`away_rating_move`
(centred), `home_strength_shift`/`away_strength_shift` (after gate), `matchup_shift` (before weight/cap),
`rating_ref_snapshot_id`, `rating_now_snapshot_id`. State: `is_frozen`, `frozen_at_version`,
`last_updated_version`, `source_game_id`. Baseline audit table (per team: win total, expected wins used,
win-total rating, lines-only rating, baseline rating and sd) lives in `rating_state.json` and
`team_ratings_latest.csv`.

## 6. Limitations and calibration
* **Policy and filter defaults are now backtested on 2012–2025 real data** (BACKTEST_RESULTS.md); `preseason_line_sd`
  is still a prior. Original note: defaults were principled priors, marked `[PRIOR]` in the
  config. To calibrate, no game outcomes are needed — use **line-to-line prediction**: over several past
  seasons, for each stale game, the target is the line actually posted later. Regress (later line − stale anchor,
  in logit) on the gated movement by line age (slope ≈ `sens · w(age)`); grid-search `threshold`,
  `half_weight_weeks`, `process_sd_per_week`, `fresh_line_sd`, `preseason_line_sd` on out-of-sample squared
  logit error. **In season the system self-checks:** each run's "adjustment skill" line scores last run's adjusted
  probabilities against the fresh lines that just arrived (`state/runs/*.json`, `details.adjustment_skill`).
* **Attribution stays partly ambiguous** early in the season (§0 flaw 4), and a Gaussian filter under-reacts to a
  single large innovation (a QB injury is a jump, not a random-walk step). Gate and cap bound the harm.
* **Dispersion drift.** If lookahead lines are shaded toward 50% and fresh lines are not, all ratings spread out
  and strong teams "improve" spuriously. Each run reports `scale_drift_slope` (regression of rating change on
  level) as a diagnostic; there is no automatic correction.
* Neutral-site / international games must be listed in `rating.neutral_site_games`; otherwise a mis-specified
  home-field term creates ~0.25-logit fake movement for both teams (tested).
* A *newly received* line carrying an old timestamp is anchored to the current snapshot, so its own staleness
  is not measured until the next run. Age is calendar time. Freezing is week-level per the spec. Integer win
  totals ignore pushes. No concurrency lock. Google Sheets reading uses the CSV-export URL (sheet must be
  link-shared or published) and is **untested** (no network in my environment); local CSV/XLSX are tested.

## 7. Verification performed
78 automated tests (`pytest tests`): de-vig and odds edge cases; aging-curve properties; gating; cases A–E;
bounds/complementarity for both links; win-total solve recovers ratings exactly and is schedule-adjusted; vig
normalisation; O/U price direction; win-total table validation; Kalman properties (equal-prior split, prior-
variance split, positive error correlation, accumulation, PSD, means unchanged by time); neutral-site and
lookahead effects; baseline weight monotone in `preseason_line_sd`; exact save/load round-trip; freeze protection;
newer/same/older timestamps; 1-row to whole-slate tables; matching independent of row order and name style;
swapped home/away; duplicates; bad-row isolation; abort paths; hash-chain and tamper detection (master and rating
state); dry run writes nothing; anchoring / no stacking; per-game snapshot reference prevents double counting;
idempotent re-runs; live skill check. **Mutation checks:** deliberately reintroducing double counting, disabling
the frozen-week check, or stacking adjustments each makes tests fail.

Bugs found by testing and fixed: pandas' default CSV float parser is 1 ULP off, which drifted frozen
probabilities across runs (now exact round-trip + exact frozen check); the naive home-field estimate was biased by
schedule imbalance (now a regression intercept); the "lines-only" diagnostic yardstick depended on the setting it
evaluates (now independent).

**Synthetic comparison** (`demo/evaluate_demo.py`, 8 seasons, never-refreshed games in weeks 11–18, MAE vs the true
probability: stale 5.7pp):

| Baseline | Win-total weight | MAE adjusted | Error cut | Stale games adjusted |
|---|---|---|---|---|
| pure win totals (`reconcile = false`) | 100% | 4.19pp | 26.5% | 72% |
| **default (`preseason_line_sd = 0.60`)** | ~50% | 4.18pp | 26.7% | 58% |
| lines-heavy (`preseason_line_sd = 0.25`) | ~15% | 4.19pp | 26.5% | 56% |

*Caveat: the generator builds preseason lines, fresh lines and win totals from the same latent strengths, so this
shows the mechanism works and that the baseline choice mostly washes out as evidence accumulates; it says nothing
about real-world accuracy or how large your win-total-vs-lines gap is.*
