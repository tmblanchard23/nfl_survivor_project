# Backtest results — real NFL data, 2012–2025

**Data.** Preseason win totals for all 32 teams, 2012–2025 (448 team-seasons), transcribed from SportsOddsHistory
(Covers), the archive Pro-Football-Reference's odds pages cite; PFR itself blocked automated access. 2011 omitted
as agreed. Every season has 32 teams; one source typo (PHI 2023 "115" → 11.5). **Integrity check:** the source's
actual-wins column matched wins computed from nflverse game results for **447/448** team-seasons; the one mismatch
(NYG 2025: source 5, nflverse 4 — verified game by game) is a source error in the results column and does not touch
the win total. Game lines: nflverse closing moneylines, **3,662 regular-season games**, de-vigged exactly as the engine does.

**Protocol.** Target = the real *closing line* a game later receives (not win/loss outcomes; closing lines are near
noise-free, so far fewer games are needed). Everything tuned on **2012–2022**, scored on a **2023–2025 holdout**; a game is
predicted only from closing lines of earlier weeks; win totals use no results; home field is walk-forward (prior three
seasons, 2020 excluded). Scripts: `backtest/run_backtest.py` (T1–T3), `backtest/replay_engine.py` (T4); raw outputs in
`backtest/results/`. Both run in about 30 seconds each.

## Headline
1. **Your core methodology is validated.** Win totals, turned into schedule-adjusted ratings, predict real Week-1 closing
   lines to **0.258 logit RMSE (≈ 1.8 points)** — better than a prior-season carryover (0.452) in **14 of 14 seasons**.
2. **The rating filter was already well calibrated.** Its parameters needed no change.
3. **The adjustment policy was too timid.** It captured about half the available improvement. Retuned defaults nearly
   **double the error reduction on stale lines (6.6% → 11.7% on the holdout; 7.4% → 13.8% in the full-engine replay, better
   in every season)**, while keeping your 3-week freshness rule, a small evidence gate and a safety cap.
4. **The production code ran cleanly on five real seasons** (180 versioned runs, every one validated, zero rejected rows).

## T1 — Anchor accuracy (RMSE in logit vs real closing lines)
| Anchor | Week 1 | Weeks 1–2 | Train 2012–22 | Holdout 2023–25 |
|---|---|---|---|---|
| **Win totals (additive vig removal, shipped)** | **0.258** | **0.300** | 0.310 | 0.261 |
| Win totals, proportional vig removal | 0.258 | 0.300 | 0.310 | 0.258 |
| Win totals × 0.9 | 0.260 | 0.300 | 0.314 | 0.240 |
| 75% win totals + 25% carryover | 0.270 | 0.304 | 0.320 | 0.238 |
| 50/50 blend | 0.313 | 0.339 | 0.357 | 0.266 |
| Prior-season carryover | 0.452 | 0.468 | 0.481 | 0.418 |

Win totals beat carryover in every season (RMSE advantage 90% CI 0.13–0.20). Blending with carryover does not help
overall. Vig-removal method does not matter. Scaling the ratings is inconsistent (train prefers 1.0, holdout 0.8–0.9), so
no scale parameter was added. **No change.**

## T2 — Filter dynamics (one-step-ahead RMSE, logit)
| | Train | Holdout | Holdout weeks 1–4 | Holdout weeks 5–18 |
|---|---|---|---|---|
| Win-total anchor, best cell (q .09, line_sd .14, prior_sd .10) | 0.3984 | 0.4149 | **0.303** | 0.4436 |
| Win-total anchor, cell nearest shipped (.09, .14, .15) | 0.3989 | 0.4152 | 0.304 | — |
| Carryover anchor, best cell | 0.4165 | 0.4281 | 0.370 | 0.4445 |

The surface is flat: the best ten cells span only 0.0005 RMSE, so the shipped values (q 0.08, line_sd 0.15, prior_sd 0.15)
are effectively optimal. `prior_sd` 0.10–0.15 fits best (0.45 is clearly worse), and the moment check agrees: the Week-1
error of 0.26 logit implies about 0.15 per team. The win-total anchor's advantage is large in weeks 1–4 and gone by week 5,
exactly the "prior fades as evidence accumulates" behaviour the design intends. **No change.**

**Home field** (market regression intercept) fell from 0.36 logit in 2012 to 0.22 in 2025. The engine estimates it from each
season's preseason lines, so this is handled automatically; the `hfa_mode = "fixed"` fallback moved 0.25 → 0.22.

## T3 — Adjustment policy (predicting closing lines ≥ 2 weeks past the information set)
20,451 train / 6,120 holdout game-predictions; error reduction vs the stale anchor:

| Policy (start age, half-weight, max weight, threshold, cap) | Train | Holdout | All-season 90% CI |
|---|---|---|---|
| Previous defaults (3, 3.0, 0.8, 0.12, 0.4) | 6.8% | 6.6% | 6.2–7.3% |
| **Shipped defaults (3, 0.5, 1.0, 0.02, 1.0)** | **12.6%** | **11.7%** | **10.8–13.8%** |
| Best found on train (1, 0.25, 1.0, 0, 1.5) | 13.3% | 12.1% | 10.9–14.8% |
| Full pass-through (no ramp, gate or cap) | 13.1% | 11.8% | 10.4–14.9% |

Why the old policy lost half the gain:
* **The filter already shrinks by its own uncertainty.** The best unconstrained pass-through slope is 0.81 for the youngest
  lines and 0.89–0.92 thereafter. The fast ramp (weight 0.58 at 3.7 weeks, 0.80 at 5, 0.89 at 7) reproduces that; the old
  slow ramp (0.8 × x/(x+3)) roughly halved it.
* **Small moves carry signal.** Slope 0.96 for movements under 0.05 logit and 0.94 for 0.1–0.4, so the 0.12 dead-zone
  discarded information. The gate is now 0.02 logit (≈ 0.15 points): it only suppresses churn from trivial moves.
* **The 0.4 cap bound 13% of real adjustments.** Real rating movements are large: the median is 0.20 logit, the 90th
  percentile 0.66. A cap of 1.0 binds on 0.1% of adjustments and keeps nearly all the gain (a cap of 1.5 adds only 0.15 points).
* **Your 3-week freshness rule costs almost nothing.** With other settings re-optimised, start age 3 reaches 13.2% against
  13.3% for ages 0–2, so it is kept.

## T4 — Full-engine replay 2021–2025 (production package, real files, hash-verified state)
| Config | Predictions | Error cut | Per season |
|---|---|---|---|
| Previous defaults | 10,255 | 7.4% | 6.3 / 8.3 / 8.9 / 7.9 / 5.9% |
| **Shipped defaults** | 10,255 | **13.8%** | **10.8 / 16.6 / 17.5 / 15.3 / 9.7%** |

The engine's built-in skill check agreed: across 950 adjusted games that later received fresh lines, error fell from 0.511
to 0.325 logit. Operational findings:
* **nflverse writes the Rams as "LA".** The engine rejects that as ambiguous by design, so the alias `LA → LAR` was needed.
* **Neutral-site games** came from nflverse's `location` field.
* **2022's 271-game season** (cancelled BUF@CIN) raised only the intended warning.

## Calibration changes shipped (config.toml / config.py; pinned by a test)
| Parameter | Before | After | Evidence |
|---|---|---|---|
| `aging.half_weight_weeks` | 3.0 | **0.5** | T3 pass-through slopes |
| `aging.max_weight` | 0.80 | **1.00** | T3 (the filter already shrinks) |
| `strength.threshold_up/down` | 0.12 | **0.02** | T3 slope by movement size |
| `adjust.cap` | 0.40 | **1.00** | T3 cap sensitivity (binding 13% → 0.1%) |
| `rating.hfa_logit` (fixed fallback only) | 0.25 | **0.22** | T2 home-field trend |
| Unchanged, now backtested | `start_age_weeks` 3, `prior_sd` 0.15, `process_sd_per_week` 0.08, `fresh_line_sd` 0.15, additive normalisation, sensitivity 1.0 | | T1–T3 |

New worked example (anchor 65%, line 7 weeks old, weight 0.889): A's rating +0.30 → **70.3%** (was 66.8%); A +0.30 and B −0.30
→ **74.6%**; A −0.30 → **59.3%**. The maximum possible move is now +23 points at 50%, +12 at 80% and +3 at 95%.

**For your live 2026 state:** no re-initialisation is needed. Adjustments are recomputed from each game's anchor on every
run, so the next `refresh` applies the new policy; ratings, frozen weeks and history are untouched.

## What this backtest could not establish
* **`preseason_line_sd`** (how much the baseline trusts preseason game lines versus win totals). No historical preseason
  lines exist, so it stays a prior. Calibrate it from 2026 data.
* **Lines refreshed less than 3 weeks ago.** Every historical anchor was at least 2.7 weeks old.
* **Real API line noise.** Closing lines are cleaner than mid-week lines, so `fresh_line_sd` 0.15 is a floor.
* **Absolute gains will be smaller live.** The backtest's stale anchor was the win-total-implied line (RMSE 0.70 against
  later closings), and a real preseason game line is likely somewhat better. The pass-through calibration should transfer
  better than the size of the gain.
* **The replay has mild lookahead.** It fed next week's *closing* lines as if they were available on Tuesday.
* **Over/under prices** on win totals were not in the source, so the price-shading feature was not tested.

## Action items
1. **Done:** defaults recalibrated, documented and pinned by a test (78 tests pass).
2. **You:** if your odds API uses nflverse-style codes, add `"LA" = "LAR"` under `[team_aliases]`.
3. **You, this season:** archive every raw API pull. Watch the run report's `adjustment skill` line; if over roughly 50
   scored games the adjusted error is *not* below the unadjusted, fall back to `max_weight 0.8, cap 0.6`.
4. **After the 2026 season:** append 2026 and rerun `backtest/run_backtest.py`, then calibrate `preseason_line_sd` from
   the archived pulls.
