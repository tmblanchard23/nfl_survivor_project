# Google Sheets bridge — setup and weekly use

The Python engine runs on your computer. The Google Sheet is its input and output. The bridge **reads** your input tabs,
runs the engine, and **writes only its own tabs** (dark-blue tab colour). Engine state (versions, ratings, audit trail) stays
in `state/` on your computer; the sheet holds the human-readable results and the archive of every grid.

## 1. Target sheet layout
| Tab | Role | Who writes it |
|---|---|---|
| **Game Lines** | ONLY the pulled lines. Any number of rows, any weeks, any order. No week column needed: every row is matched to its scheduled game by the two teams plus the game date. | your odds script |
| **Pools Picks** | your pool's picks (for the separate optimisation project) | you |
| **Preseason Win Totals** | read once, at bootstrap | you (already done) |
| **Preserved Week 1 Full Season Lines** | full-season opening lines = the season schedule; read once, at bootstrap | already done |
| **Probability Grid (Latest)** | Team × Week 1–18 grid; **overwritten every build** — point downstream work at this tab | bridge |
| **Grid 2026 W03 v003** … | one archive tab per build, never overwritten | bridge |
| **Master Game Table** | every matchup of the season with current probabilities and where they came from (replaces "Algorithm Game Lines") | bridge |
| **Team Ratings** | market-implied power ratings in spread points (a replacement for the Super-Bowl-based "Power Ranking") | bridge |
| **Grid Run Log** | one row per build: lines applied, rows skipped or set aside, rejections, the adjustment-skill check | bridge |

**You can delete:** Algorithm Game Lines, Week Lookup Table (the bridge infers weeks itself; its January dates also had the
wrong year), and the "2026 Schedule" tab (the full-season lines already define the schedule). **Super Bowl Futures** is no
longer used by the grid; keep pulling it only if something else of yours uses it (it costs API requests).

### What the Game Lines tab must contain (your odds script's contract)
Header row anywhere in the first 25 rows (metadata rows above it are fine). Required headers (names editable in
`config.toml`): `Game Time`, `Away Team`, `Home Team`, `Moneyline Away`, `Moneyline Home` (decimal odds),
`Line Last Updated`. Extra columns (spreads, etc.) are ignored. Times are read as **US Eastern**.
* Rows with no odds yet → set aside as "no line yet" (reported, not an error).
* Last week's already-played games still in the pull → skipped quietly.
* Anything not on the regular-season schedule (preseason, playoffs, a date more than 6 days off) → set aside and reported.
* A team name the engine does not recognise → **rejected and named** in the run log (add it under `[team_aliases]`).
* A line is only applied if its `Line Last Updated` is newer than the one already stored, so re-running is always safe.

## 2. One-time Google setup (about 10 minutes)
1. Go to <https://console.cloud.google.com/>, create a project (any name).
2. **APIs & Services → Library →** enable **Google Sheets API**.
3. **APIs & Services → Credentials → Create credentials → Service account.** Open it → **Keys → Add key → JSON**.
   Save the file as `service_account.json` in the project folder. **Treat it like a password; never commit or share it.**
4. Open the JSON, copy the `client_email` (…@….iam.gserviceaccount.com). In your Google Sheet: **Share** → paste that
   address → **Editor**.
5. In the sheet: **File → Settings → Time zone = (GMT-05:00) Eastern Time.** Dates and times are read as serial
   numbers in the sheet's time zone.
6. Install: `pip install -r requirements.txt` (adds `gspread` and `google-auth`).
7. In `config.toml`, under `[sheets]`: paste the sheet URL into `spreadsheet`. **Check `initial_lines_tab`:** Excel cut
   your tab name to 31 characters ("Preserved Week 1 Full Season Li"). In Google it is probably the full name — enter it
   exactly as shown in the sheet.

Check everything without changing anything:
```bash
python -m nfl_prob_grid sheets status
```

## 3. First run (mid-season catch-up)
We are in week 3, so the first run rebuilds the season's history in the right order: opening lines + win totals (9/8)
→ the Week-2 export (9/17) → the current Game Lines tab.
```bash
python -m nfl_prob_grid sheets bootstrap --catch-up "Preserved Week 2 Line Export"
```
This writes the Latest grid, archive tabs for each step (W01, W02, W03), the Master Game Table, Team Ratings and the Run Log.

## 4. Every week
After your odds script refreshes Game Lines:
```bash
python -m nfl_prob_grid sheets build            # add --dry-run to preview without writing anything
```
The current week is inferred from the calendar (a week is completed the day after its last game).
`--current-week N` overrides it; the engine refuses any value that would unfreeze a completed week.

If a build's sheet write fails (network, permissions), the engine state is already safe; repair the sheet with:
```bash
python -m nfl_prob_grid sheets publish
```
Publishing is rendered from saved state, so it is safe to repeat and never duplicates Run Log rows.

## 5. Things to set once
* **International / neutral-site games:** home field must be switched off for them, or both teams' ratings pick up
  ~0.25 logit of fake movement. Copy their `Game ID` from the Master Game Table into `[rating] neutral_site_games`.
* **Team names:** full names, nicknames and common abbreviations all work. Ambiguous ones ("LA", "New York") are
  rejected on purpose; map them under `[team_aliases]` if your feed uses them.

## 6. Working offline / testing
Point `spreadsheet` at a local `.xlsx` with the same tabs. Your workbook is opened **read-only and never saved**: outputs
go to a companion file `<name> - Grid Outputs.xlsx`. (Re-saving a workbook with Excel libraries rewrites every tab, which
can shift numbers in the 16th digit.)

## 7. Safety guarantees (all covered by tests)
* Input tabs are never written. On Google the bridge only clears or writes the output tabs. Locally your workbook stays
  byte-for-byte identical.
* Output tab names that collide with an input tab are refused at start-up.
* All writes are values (RAW), so nothing is interpreted as a formula.
* A failed engine run writes nothing anywhere.
